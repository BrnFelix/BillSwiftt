package com.uj.billswift.infra.dto;

public record LoginRequestDTO(String email, String password) {}
