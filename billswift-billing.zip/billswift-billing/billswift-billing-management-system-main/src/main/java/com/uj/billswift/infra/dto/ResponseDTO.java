package com.uj.billswift.infra.dto;

public record ResponseDTO (String name, String token) {}
