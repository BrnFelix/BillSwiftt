package com.uj.billswift;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillswiftApplicationTests {

	@Test
	void contextLoads() {
	}

}
